<?php
// Database configuration
return [
  'host' => '127.0.0.1',
  'db' => 'meca_anciennes',
  'user' => 'root',
  'pass' => '',
  'charset' => 'utf8mb4',
];
